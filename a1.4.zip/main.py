from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController
import json, time, os, random
from pathlib import Path
from PIL import Image

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

app = Ursina()

application.asset_folder = Path(BASE_DIR)

plr = FirstPersonController(position=(5, 15, 5))

world = Entity()

pause_handler = Entity(ignore_paused=True)

application.pause()

selected_world = 1

background = Entity(
    parent=camera.ui,
    model='quad',
    texture='textures/menu_background.png',
    scale=(camera.aspect_ratio, 1),
    ignore_paused=True,
    z=1
)

def w1_func():
    global selected_world
    selected_world = 1

def w2_func():
    global selected_world
    selected_world = 2

def w3_func():
    global selected_world
    selected_world = 3

def w4_func():
    global selected_world
    selected_world = 4

def w5_func():
    global selected_world
    selected_world = 5

def load_world():
    global stats
    world_path = os.path.join(BASE_DIR, 'worlds', str(selected_world), 'world.json')
    stats_path = os.path.join(BASE_DIR, 'worlds', str(selected_world), 'stats.json')

    if not os.path.exists(world_path) or os.path.getsize(world_path) == 0:
        for block_type in inventory_items:
            inventory[block_type] = 0
        for x in range(0, 10):
            for z in range(0, 10):
                create_block((x, 1, z), 'grass')

        for x in range(0, 10):
            for y in range(-2, 1):
                for z in range(0, 10):
                    create_block((x, y, z), 'dirt')

        for x in range(0, 10):
            for y in range(-10, -2):
                for z in range(0, 10):
                    create_block((x, y, z), 'stone')

        for x in range(0, 10):
            for z in range(0, 10):
                create_block((x, -11, z), 'bedrock')

        for x in range(0, 10):
            for z in range(0, 10):
                if random.randint(1, 100) == 1:
                    # Ствол дерева (высота 4 блока)
                    create_block((x, 2, z), 'oak_log')
                    create_block((x, 3, z), 'oak_log')
                    create_block((x, 4, z), 'oak_log')
                    create_block((x, 5, z), 'oak_log')
                    
                    # Крона: слой 6 (широкий)
                    create_block((x, 6, z), 'oak_leaves')
                    create_block((x + 1, 6, z), 'oak_leaves')
                    create_block((x - 1, 6, z), 'oak_leaves')
                    create_block((x, 6, z + 1), 'oak_leaves')
                    create_block((x, 6, z - 1), 'oak_leaves')
                    create_block((x + 1, 6, z + 1), 'oak_leaves')
                    create_block((x + 1, 6, z - 1), 'oak_leaves')
                    create_block((x - 1, 6, z + 1), 'oak_leaves')
                    create_block((x - 1, 6, z - 1), 'oak_leaves')
                    
                    # Крона: слой 7 (средний)
                    create_block((x, 7, z), 'oak_leaves')
                    create_block((x + 1, 7, z), 'oak_leaves')
                    create_block((x - 1, 7, z), 'oak_leaves')
                    create_block((x, 7, z + 1), 'oak_leaves')
                    create_block((x, 7, z - 1), 'oak_leaves')
                    
                    # Крона: слой 8 (верхушка)
                    create_block((x, 8, z), 'oak_leaves')
                    create_block((x, 9, z), 'oak_leaves')  # верхний блок
    else:
        with open(world_path, 'r') as save:
            data = json.load(save)
            for grass in data.get('grass', []):
                create_block(tuple(grass), 'grass')
            for dirt in data.get('dirt', []):
                create_block(tuple(dirt), 'dirt')
            for stone in data.get('stone', []):
                create_block(tuple(stone), 'stone')
            for bedrock in data.get('bedrock', []):
                create_block(tuple(bedrock), 'bedrock')
            for oak_log in data.get('oak_log', []):
                create_block(tuple(oak_log), 'oak_log')
            for oak_leaves in data.get('oak_leaves', []):
                create_block(tuple(oak_leaves), 'oak_leaves')

        if os.path.exists(stats_path):
            with open(stats_path, 'r') as save:
                try:
                    stats = json.load(save)
                except:
                    pass

        inv_path = os.path.join(BASE_DIR, 'worlds', str(selected_world), 'inv.json')
        if os.path.exists(inv_path):
            try:
                with open(inv_path, 'r') as save:
                    saved_inventory = json.load(save)
                for block_type in inventory_items:
                    if block_type in saved_inventory:
                        inventory[block_type] = saved_inventory[block_type]
            except:
                pass

    background.enabled = False
    application.resume()
    mouse.locked = True
    mouse.visible = False
    w1.enabled = False
    w2.enabled = False
    w3.enabled = False
    w4.enabled = False
    w5.enabled = False
    load_w.enabled = False

w1 = Button(
    parent=camera.ui,
    text='World 1',
    scale=(1, 0.08),
    position=(0, 0.3),
    color=color.red,
    on_click=w1_func
)

w2 = Button(
    parent=camera.ui,
    text='World 2',
    scale=(1, 0.08),
    position=(0, 0.2),
    color=color.red,
    on_click=w2_func
)

w3 = Button(
    parent=camera.ui,
    text='World 3',
    scale=(1, 0.08),
    position=(0, 0.1),
    color=color.red,
    on_click=w3_func
)

w4 = Button(
    parent=camera.ui,
    text='World 4',
    scale=(1, 0.08),
    position=(0, 0),
    color=color.red,
    on_click=w4_func
)

w5 = Button(
    parent=camera.ui,
    text='World 5',
    scale=(1, 0.08),
    position=(0, -0.1),
    color=color.red,
    on_click=w5_func
)

load_w = Button(
    parent=camera.ui,
    text='Load selected world',
    scale=(1, 0.08),
    position=(0, -0.2),
    color=color.green,
    on_click=load_world
)

mouse.locked = False
mouse.visible = True

blocks = {'grass': [], 'dirt': [], 'stone': [], 'bedrock': [], 'oak_log': [], 'oak_leaves': []}
stats = {'blocks_crushed': 0, 'blocks_placed': 0, 'world_saves': 0}

textures = {
    'grass': 'textures/grass.png',
    'dirt': 'textures/dirt.png',
    'stone': 'textures/stone.png',
    'bedrock': 'textures/bedrock.png',
    'oak_log': 'textures/oak_log.png',
    'oak_leaves': 'textures/oak_leaves.png'
}

loaded_textures = {}

def get_texture(block_type):
    if block_type not in loaded_textures:
        path = os.path.join(BASE_DIR, textures[block_type])
        loaded_textures[block_type] = Texture(Image.open(path).convert('RGBA'))
    return loaded_textures[block_type]

inventory_items = ['grass', 'dirt', 'stone', 'oak_log', 'oak_leaves']
item_names = {
    'grass': 'Grass',
    'dirt': 'Dirt',
    'stone': 'Stone',
    'oak_log': 'Oak Log',
    'oak_leaves': 'Oak Leaves'
}
inventory = {block_type: 0 for block_type in inventory_items}
selected_slot = 0
last_hovered = None

def inventory_panel():
    lines = ['Инвентарь:']
    for number, block_type in enumerate(inventory_items, start=1):
        marker = '>' if number == selected_slot + 1 else ' '
        lines.append(f'{marker}{number} - {item_names[block_type]}: {inventory[block_type]}')
    return '\n'.join(lines)

info_text = Text(
    text=inventory_panel(),
    parent=camera.ui,
    position=(-0.85, 0.45),
    scale=1.5,
    color=color.white
)

def create_block(pos, block_type):
    global stats
    block = Entity(model='cube', collider='box', position=pos, texture=get_texture(block_type))
    block.block_type = block_type
    blocks[block_type].append(block)
    return block

def update():
    global last_hovered
    current = mouse.hovered_entity if hasattr(mouse.hovered_entity, 'block_type') else None

    info_text.text = inventory_panel()

    if current != last_hovered:
        if last_hovered:
            last_hovered.color = color.white
        if current:
            current.color = color.red
        last_hovered = current

def input(key):
    global selected_slot, last_hovered

    if key in ('1', '2', '3', '4', '5'):
        selected_slot = int(key) - 1

    if key == 'scroll up':
        selected_slot = (selected_slot - 1) % len(inventory_items)
    if key == 'scroll down':
        selected_slot = (selected_slot + 1) % len(inventory_items)

    if key == 'left mouse down' and mouse.hovered_entity:
        target = mouse.hovered_entity
        if hasattr(target, 'block_type') and target.block_type != 'bedrock':
            if target == last_hovered:
                last_hovered = None
            blocks[target.block_type].remove(target)
            inventory[target.block_type] += 1
            stats['blocks_crushed'] += 1
            destroy(target)

    if key == 'right mouse down' and mouse.hovered_entity:
        if hasattr(mouse.hovered_entity, 'block_type'):
            block_type = inventory_items[selected_slot]
            if inventory[block_type] > 0:
                new_pos = mouse.hovered_entity.position + mouse.normal
                inventory[block_type] -= 1
                stats['blocks_placed'] += 1
                create_block(new_pos, block_type)

    if key == 'z':
        print('Saving...')
        start_time = time.perf_counter()
        data = {'grass': [], 'dirt': [], 'stone': [], 'bedrock': [], 'oak_log': [], 'oak_leaves': []}
        for block in blocks['grass']:
            data['grass'].append((block.x, block.y, block.z))
        for block in blocks['dirt']:
            data['dirt'].append((block.x, block.y, block.z))
        for block in blocks['stone']:
            data['stone'].append((block.x, block.y, block.z))
        for block in blocks['bedrock']:
            data['bedrock'].append((block.x, block.y, block.z))
        for block in blocks['oak_log']:
            data['oak_log'].append((block.x, block.y, block.z))
        for block in blocks['oak_leaves']:
            data['oak_leaves'].append((block.x, block.y, block.z))
        stats['world_saves'] += 1
        print(f'Saved in {time.perf_counter() - start_time} seconds!')

        world_dir = os.path.join(BASE_DIR, 'worlds', str(selected_world))
        os.makedirs(world_dir, exist_ok=True)

        with open(os.path.join(world_dir, 'world.json'), 'w') as file:
            json.dump(data, file, indent=4, ensure_ascii=False)

        with open(os.path.join(world_dir, 'stats.json'), 'w') as file:
            json.dump(stats, file, indent=4, ensure_ascii=False)

        with open(os.path.join(world_dir, 'inv.json'), 'w') as file:
            json.dump(inventory, file, indent=4, ensure_ascii=False)

def pause_handler_input(key):
    if key == 'escape':
        application.paused = not application.paused
        if application.paused:
            info_text.text = 'Игра на паузе'
        else:
            info_text.text = inventory_panel()

pause_handler.input = pause_handler_input

plr.speed = 10
plr.gravity = 1
plr.height = 1.7
plr.jump_height = 1.1

Sky()
app.run()