from PyQt5.QtWidgets import *
import os, subprocess

def start_f():
    global combo
    subprocess.Popen(['python', f'instances\\{combo.currentText()}\\main.py'])

instances = []

app = QApplication([])

w = QWidget()

layout = QVBoxLayout(w)

for fn in os.listdir('instances'):
    if os.path.isdir(f'instances\\{fn}'):
        instances.append(fn)

combo = QComboBox()
combo.addItems(instances)
layout.addWidget(combo)

start = QPushButton(text='Старт')
start.clicked.connect(start_f)
layout.addWidget(start)

w.show()
app.exec()