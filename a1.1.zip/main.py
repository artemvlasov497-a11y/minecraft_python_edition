from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController

app = Ursina()

plr = FirstPersonController(position=(5, 15, 5))

world = Entity()

blocks = {'grass': [], 'dirt': [], 'stone': [], 'bedrock': []}

for x in range(0, 10):
    for z in range(0, 10):
        block = Entity(model='cube', collider='box', position=(x, 1, z), texture='textures/grass.png')
        blocks['grass'].append(block)

for x in range(0, 10):
    for y in range(-2, 1):
        for z in range(0, 10):
            block = Entity(model='cube', collider='box', position=(x, y, z), texture='textures/dirt.png')
            blocks['dirt'].append(block)

for x in range(0, 10):
    for y in range(-10, -2):
        for z in range(0, 10):
            block = Entity(model='cube', collider='box', position=(x, y, z), texture='textures/stone.png')
            blocks['stone'].append(block)

for x in range(0, 10):
    for z in range(0, 10):
        block = Entity(model='cube', collider='box', position=(x, -11, z), texture='textures/bedrock.png')
        blocks['bedrock'].append(block)

plr.speed = 10
plr.gravity = 1

Sky()
app.run()