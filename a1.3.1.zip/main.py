from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController
import json, time, os

app = Ursina()

plr = FirstPersonController(position=(5, 15, 5))

world = Entity()

pause_handler = Entity(ignore_paused=True)

application.pause()

selected_world = 1

background = Entity(
    parent=camera.ui,
    model='quad',
    texture='textures\\menu_background.png',
    scale=(camera.aspect_ratio, 1),
    ignore_paused=True,
    z=1
)

def w1_func():
    global selected_world
    selected_world = 1

def w2_func():
    global selected_world
    selected_world = 2

def w3_func():
    global selected_world
    selected_world = 3

def w4_func():
    global selected_world
    selected_world = 4

def w5_func():
    global selected_world
    selected_world = 5

def load_world():
    global stats
    if os.path.getsize(f'worlds\\{str(selected_world)}\\world.json') == 0:
        for x in range(0, 10):
            for z in range(0, 10):
                create_block((x, 1, z), 'grass')

        for x in range(0, 10):
            for y in range(-2, 1):
                for z in range(0, 10):
                    create_block((x, y, z), 'dirt')

        for x in range(0, 10):
            for y in range(-10, -2):
                for z in range(0, 10):
                    create_block((x, y, z), 'stone')

        for x in range(0, 10):
            for z in range(0, 10):
                create_block((x, -11, z), 'bedrock')
    else:
        with open(f'worlds\\{str(selected_world)}\\world.json', 'r') as save:
            data = json.load(save)
            try:
                for grass in data['grass']:
                    create_block(grass, 'grass')
            except:
                pass
            try:
                for dirt in data['dirt']:
                    create_block(dirt, 'dirt')
            except:
                pass
            try:
                for stone in data['stone']:
                    create_block(stone, 'stone')
            except:
                pass
            try:
                for bedrock in data['bedrock']:
                    create_block(bedrock, 'bedrock')
            except:
                pass

        with open(f'worlds\\{selected_world}\\stats.json') as save:
            try:
                stats = json.load(save)
            except:
                pass

    background.disable()
    application.resume()
    mouse.locked = True
    mouse.visible = False
    w1.disable()
    w2.disable()
    w3.disable()
    w4.disable()
    w5.disable()
    load_w.disable()

w1 = Button(
    parent=camera.ui,
    text='World 1',
    scale=(1, 0.08),
    position=(0, 0.3),
    color=color.red,
    on_click=w1_func
)

w2 = Button(
    parent=camera.ui,
    text='World 2',
    scale=(1, 0.08),
    position=(0, 0.2),
    color=color.red,
    on_click=w2_func
)

w3 = Button(
    parent=camera.ui,
    text='World 3',
    scale=(1, 0.08),
    position=(0, 0.1),
    color=color.red,
    on_click=w3_func
)

w4 = Button(
    parent=camera.ui,
    text='World 4',
    scale=(1, 0.08),
    position=(0, 0),
    color=color.red,
    on_click=w4_func
)

w5 = Button(
    parent=camera.ui,
    text='World 5',
    scale=(1, 0.08),
    position=(0, -0.1),
    color=color.red,
    on_click=w5_func
)

load_w = Button(
    parent=camera.ui,
    text='Load selected world',
    scale=(1, 0.08),
    position=(0, -0.2),
    color=color.green,
    on_click=load_world
)

mouse.locked = False
mouse.visible = True

blocks = {'grass': [], 'dirt': [], 'stone': [], 'bedrock': []}
stats = {'blocks_crushed': 0, 'blocks_placed': 0, 'world_saves': 0}

textures = {
    'grass': 'textures/grass.png',
    'dirt': 'textures/dirt.png',
    'stone': 'textures/stone.png',
    'bedrock': 'textures/bedrock.png'
}

inventory = ['grass', 'dirt', 'stone', 'bedrock']
selected_slot = 0
last_hovered = None

info_text = Text(
    text='Выбранный блок: grass\n 1 - Grass\n 2 - Dirt\n 3 - Stone\n 4 - Bedrock',
    parent=camera.ui,      # Привязка к UI
    position=(-0.85, 0.45), # Позиция (от -0.5 до 0.5 — это диапазон экрана)
    scale=1.5,
    color=color.white
)

def create_block(pos, block_type):
    global stats
    block = Entity(model='cube', collider='box', position=pos, texture=textures[block_type])
    block.block_type = block_type
    blocks[block_type].append(block)
    return block

def update():
    global last_hovered
    current = mouse.hovered_entity if hasattr(mouse.hovered_entity, 'block_type') else None

    info_text.text = f'Выбранный блок: {selected_slot + 1}'

    if current != last_hovered:
        if last_hovered:
            last_hovered.color = color.white
        if current:
            current.color = color.red
        last_hovered = current

def input(key):
    global selected_slot, last_hovered

    if key in ('1', '2', '3', '4'):
        selected_slot = int(key) - 1

    if key == 'scroll up':
        selected_slot = (selected_slot - 1) % len(inventory)
    if key == 'scroll down':
        selected_slot = (selected_slot + 1) % len(inventory)

    if key == 'left mouse down' and mouse.hovered_entity:
        target = mouse.hovered_entity
        if hasattr(target, 'block_type') and target.block_type != 'bedrock':
            if target == last_hovered:
                last_hovered = None
            blocks[target.block_type].remove(target)
            stats['blocks_crushed'] += 1
            destroy(target)

    if key == 'right mouse down' and mouse.hovered_entity:
        if hasattr(mouse.hovered_entity, 'block_type'):
            new_pos = mouse.hovered_entity.position + mouse.normal
            stats['blocks_placed'] += 1
            create_block(new_pos, inventory[selected_slot])

    if key == 'z':
        print('Saving...')
        start_time = time.perf_counter()
        data = {'grass': [], 'dirt': [], 'stone': [], 'bedrock': []}
        for block in blocks['grass']:
            data['grass'].append((block.x, block.y, block.z))
        for block in blocks['dirt']:
            data['dirt'].append((block.x, block.y, block.z))
        for block in blocks['stone']:
            data['stone'].append((block.x, block.y, block.z))
        for block in blocks['bedrock']:
            data['bedrock'].append((block.x, block.y, block.z))
        stats['world_saves'] += 1
        print(f'Saved in {time.perf_counter() - start_time} seconds!')

        with open(f'worlds\\{str(selected_world)}\\world.json', 'w') as file:
            json.dump(data, file, indent=4, ensure_ascii=False)

        with open(f'worlds\\{str(selected_world)}\\stats.json', 'w') as file:
            json.dump(stats, file, indent=4, ensure_ascii=False)

def pause_handler_input(key):
    if key == 'escape':
            application.paused = not application.paused
            if application.paused:
                info_text.text = 'Игра на паузе'
            else:
                info_text.text = selected_slot + 1

pause_handler.input = pause_handler_input

plr.speed = 10
plr.gravity = 1
plr.height = 1.7
plr.jump_height = 1.1

Sky()
app.run()