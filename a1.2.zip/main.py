from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController
import json, time, os

app = Ursina()

plr = FirstPersonController(position=(5, 15, 5))

world = Entity()

blocks = {'grass': [], 'dirt': [], 'stone': [], 'bedrock': []}
textures = {
    'grass': 'textures/grass.png',
    'dirt': 'textures/dirt.png',
    'stone': 'textures/stone.png',
    'bedrock': 'textures/bedrock.png'
}
inventory = ['grass', 'dirt', 'stone', 'bedrock']
selected_slot = 0
last_hovered = None

def create_block(pos, block_type):
    block = Entity(model='cube', collider='box', position=pos, texture=textures[block_type])
    block.block_type = block_type
    blocks[block_type].append(block)
    return block

if not os.path.exists('world.json') or os.path.getsize('world.json') == 0:
    for x in range(0, 10):
        for z in range(0, 10):
            create_block((x, 1, z), 'grass')

    for x in range(0, 10):
        for y in range(-2, 1):
            for z in range(0, 10):
                create_block((x, y, z), 'dirt')

    for x in range(0, 10):
        for y in range(-10, -2):
            for z in range(0, 10):
                create_block((x, y, z), 'stone')

    for x in range(0, 10):
        for z in range(0, 10):
            create_block((x, -11, z), 'bedrock')
else:
    with open('world.json', 'r') as save:
        data = json.load(save)
        try:
            for grass in data['grass']:
                create_block(grass, 'grass')
        except:
            pass
        try:
            for dirt in data['dirt']:
                create_block(dirt, 'dirt')
        except:
            pass
        try:
            for stone in data['stone']:
                create_block(stone, 'stone')
        except:
            pass
        try:
            for bedrock in data['bedrock']:
                create_block(bedrock, 'bedrock')
        except:
            pass

def update():
    global last_hovered
    current = mouse.hovered_entity if hasattr(mouse.hovered_entity, 'block_type') else None

    if current != last_hovered:
        if last_hovered:
            last_hovered.color = color.white
        if current:
            current.color = color.red
        last_hovered = current

def input(key):
    global selected_slot, last_hovered

    if key in ('1', '2', '3', '4'):
        selected_slot = int(key) - 1

    if key == 'scroll up':
        selected_slot = (selected_slot - 1) % len(inventory)
    if key == 'scroll down':
        selected_slot = (selected_slot + 1) % len(inventory)

    if key == 'left mouse down' and mouse.hovered_entity:
        target = mouse.hovered_entity
        if hasattr(target, 'block_type') and target.block_type != 'bedrock':
            if target == last_hovered:
                last_hovered = None
            blocks[target.block_type].remove(target)
            destroy(target)

    if key == 'right mouse down' and mouse.hovered_entity:
        if hasattr(mouse.hovered_entity, 'block_type'):
            new_pos = mouse.hovered_entity.position + mouse.normal
            create_block(new_pos, inventory[selected_slot])

    if key == 'z':
        print('Saving...')
        start_time = time.perf_counter()
        data = {'grass': [], 'dirt': [], 'stone': [], 'bedrock': []}
        for block in blocks['grass']:
            data['grass'].append((block.x, block.y, block.z))
        for block in blocks['dirt']:
            data['dirt'].append((block.x, block.y, block.z))
        for block in blocks['stone']:
            data['stone'].append((block.x, block.y, block.z))
        for block in blocks['bedrock']:
            data['bedrock'].append((block.x, block.y, block.z))
        print(f'Saved in {time.perf_counter() - start_time} seconds!')

        with open('world.json', 'w') as file:
            json.dump(data, file, indent=4, ensure_ascii=False)

plr.speed = 10
plr.gravity = 1
plr.height = 1.8
plr.jump_height = 1.1

Sky()
app.run()
